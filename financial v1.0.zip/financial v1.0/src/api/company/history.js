import request from '@/utils/request'

// 查询缴费记录列表
export function listHistory(query) {
  return request({
    url: '/company/payment/list',
    method: 'get',
    params: query
  })
}

// 查询缴费记录详细
export function getHistory(id) {
  return request({
    url: '/company/payment/' + id,
    method: 'get'
  })
}

// 新增缴费记录
export function addHistory(data) {
  return request({
    url: '/company/payment',
    method: 'post',
    data: data
  })
}

// 修改缴费记录
export function updateHistory(data) {
  return request({
    url: '/company/payment',
    method: 'put',
    data: data
  })
}

// 删除缴费记录
export function delHistory(id) {
  return request({
    url: '/company/payment/' + id,
    method: 'delete'
  })
}
