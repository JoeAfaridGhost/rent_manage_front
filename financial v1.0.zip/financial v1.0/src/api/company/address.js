import request from '@/utils/request'

// 查询租赁场地列表
export function listAddress(query) {
  return request({
    url: '/company/address/list',
    method: 'get',
    params: query
  })
}

// 查询租赁场地详细
export function getAddress(id) {
  return request({
    url: '/company/address/' + id,
    method: 'get'
  })
}

// 新增租赁场地
export function addAddress(data) {
  return request({
    url: '/company/address',
    method: 'post',
    data: data
  })
}

// 修改租赁场地
export function updateAddress(data) {
  return request({
    url: '/company/address',
    method: 'put',
    data: data
  })
}

// 删除租赁场地
export function delAddress(id) {
  return request({
    url: '/company/address/' + id,
    method: 'delete'
  })
}
