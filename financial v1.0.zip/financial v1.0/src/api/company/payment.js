import request from '@/utils/request'

// 导出催款单
export function exportCKD(data) {
  return request({
    url: '/company/payment/check',
    method: 'put',
    data: data
  })
}

// 修改公司支付信息
export function checkPayment(data) {
  return request({
    url: '/company/payment/check',
    method: 'put',
    data: data
  })
}


export function listUnpaid(query) {
  return request({
    url: '/company/payment/listUnpaid',
    method: 'get',
    params: query
  })
}

// 查询公司支付信息列表
export function listPayment(query) {
  return request({
    url: '/company/payment/list',
    method: 'get',
    params: query
  })
}

// 查询公司支付信息详细
export function getPayment(id) {
  return request({
    url: '/company/payment/' + id,
    method: 'get'
  })
}

// 新增公司支付信息
export function addPayment(data) {
  return request({
    url: '/company/payment',
    method: 'post',
    data: data
  })
}

// 修改公司支付信息
export function updatePayment(data) {
  return request({
    url: '/company/payment',
    method: 'put',
    data: data
  })
}

// 删除公司支付信息
export function delPayment(id) {
  return request({
    url: '/company/payment/' + id,
    method: 'delete'
  })
}
