import request from '@/utils/request'

// 审批合同
export function checkContract(data) {
  return request({
    url: '/company/contract/audit',
    method: 'put',
    data: data
  })
}

// 查询公司合同列表
export function listContract(query) {
  return request({
    url: '/company/contract/list',
    method: 'get',
    params: query
  })
}

// 查询公司合同详细
export function getContract(id) {
  return request({
    url: '/company/contract/' + id,
    method: 'get'
  })
}

// 新增公司合同
export function addContract(data) {
  return request({
    url: '/company/contract',
    method: 'post',
    data: data
  })
}

// 修改公司合同
export function updateContract(data) {
  return request({
    url: '/company/contract',
    method: 'put',
    data: data
  })
}

// 删除公司合同
export function delContract(id) {
  return request({
    url: '/company/contract/' + id,
    method: 'delete'
  })
}
