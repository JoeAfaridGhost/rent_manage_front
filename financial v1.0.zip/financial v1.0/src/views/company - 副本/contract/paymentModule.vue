<template>
  <ContentWrap>
    <el-table v-loading="loading" :data="paymentList" :stripe="true" :show-overflow-tooltip="true" >
<!--      <el-table-column label="序号" align="center" prop="id" />-->
      <el-table-column label="序号" align="center">
        <template #default="{ $index }">
          {{ (queryParams.pageNum - 1) * queryParams.pageSize + $index + 1 }}
        </template>
      </el-table-column>
<!--      <el-table-column label="合同编号" align="center" prop="contractCode" />-->
<!--      <el-table-column label="公司名称" align="center" prop="companyName" />-->
<!--      <el-table-column label="交费时段" align="center">-->
<!--        <template #default="scope">-->
<!--          <span>-->
<!--            {{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}-->
<!--            至-->
<!--            {{ parseTime(scope.row.endDate, '{y}-{m}-{d}') }}-->
<!--          </span>-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="开始日期" align="center" prop="startDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="结束日期" align="center" prop="endDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.endDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="租金" align="center" prop="rentFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="物业费" align="center" prop="propertyFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="交费金额（总）" align="center" prop="totalFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="实际支付" align="center" prop="actualPayment"
          :formatter="formatTwoDecimalPlaces"
      />
<!--      <el-table-column label="备注" align="center" prop="notes" :formatter="formatNotes" />-->
      <el-table-column label="是否缴清" align="center">
        <template #default="scope">
          <span :style="{ color: getPaymentStatus(scope.row.actualPayment, scope.row.totalFee).color }">
            {{ getPaymentStatus(scope.row.actualPayment, scope.row.totalFee).text }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <div style="display: flex; flex-wrap: wrap; justify-content: center; ">
            <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['company:payment:edit']">修改</el-button>
<!--            <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['company:payment:remove']">删除</el-button>-->
            <el-button v-if="scope.row.actualPayment !== scope.row.totalFee "
                       link type="primary" icon="Coin" @click="handleCheck(scope.row)" v-hasPermi="['company:payment:check']">缴费录入</el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <pagination
        v-show="total>0"
        :total="total"
        v-model:page="queryParams.pageNum"
        v-model:limit="queryParams.pageSize"
        @pagination="getList"
        style="margin-bottom: 20px"
    />
  </ContentWrap>

  <!-- 添加或修改公司支付信息对话框 -->
  <el-dialog :title="title" v-model="open" width="500px" append-to-body>
    <el-form ref="paymentRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="合同编号" prop="contractId">
        <el-input v-model="form.contractId" placeholder="请输入合同编号" :disabled="true"/>
      </el-form-item>
      <el-form-item label="开始日期" prop="startDate">
        <el-date-picker clearable  :disabled="true"
                        v-model="form.startDate"
                        type="date"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择开始日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="结束日期" prop="endDate">
        <el-date-picker clearable  :disabled="true"
                        v-model="form.endDate"
                        type="date"
                        value-format="YYYY-MM-DD"
                        placeholder="请选择结束日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="租金" prop="rentFee">
        <el-input v-model="form.rentFee" placeholder="请输入租金" :disabled="true"/>
      </el-form-item>
      <el-form-item label="物业费" prop="propertyFee">
        <el-input v-model="form.propertyFee" placeholder="请输入物业费"  :disabled="true"/>
      </el-form-item>
      <el-form-item label="总费用" prop="totalFee">
        <el-input v-model="form.totalFee" placeholder="请输入总费用"  :disabled="true"/>
      </el-form-item>
      <el-form-item label="实际支付" prop="actualPayment">
        <el-input v-model="form.actualPayment" placeholder="请输入实际已支付费用" />
      </el-form-item>
      <el-form-item label="付款凭证" prop="contractFile">
        <file-upload v-model="form.proof"/>
      </el-form-item>
      <el-form-item label="备注" prop="notes">
        <el-input v-model="form.notes" type="textarea" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>


  <el-dialog :title="title" v-model="openPayment" width="500px" append-to-body>
    <el-form ref="paymentRef" :model="form" :rules="rules" label-width="120px">
      <el-form-item label="实际支付" prop="actualPayment">
        <el-input v-model="form.actualPayment" placeholder="请输入实际已支付费用" />
      </el-form-item>
      <el-form-item label="付款凭证" prop="contractFile">
        <file-upload v-model="form.proof"/>
      </el-form-item>
      <el-form-item label="备注" prop="notes">
        <el-input v-model="form.notes" type="textarea" placeholder="请输入内容" />
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitPayment">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>


</template>

<script setup name="paymentModule" lang="ts">
const props = defineProps<{
  contractId?: object,
}>()

import { listPayment, getPayment, delPayment, addPayment, updatePayment, checkPayment } from "@/api/company/payment";

const { proxy } = getCurrentInstance();

const paymentList = ref([]);
const open = ref(false);
const openPayment = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    paymentId: null,
    contractId: null,
    startDate: null,
    endDate: null,
    rentFee: null,
    propertyFee: null,
    totalFee: null,
    actualPayment: null,
    proof: null,
    notes: null
  },
  rules: {
    // paymentId: [
    //   { required: true, message: "支付唯一标识不能为空", trigger: "blur" }
    // ],
    contractId: [
      { required: true, message: "合同编号不能为空", trigger: "blur" }
    ],
    startDate: [
      { required: true, message: "开始日期不能为空", trigger: "blur" }
    ],
    endDate: [
      { required: true, message: "结束日期不能为空", trigger: "blur" }
    ],
  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询公司支付信息列表 */
function getList() {
  queryParams.value.contractId = props.contractId;
  loading.value = true;
  listPayment(queryParams.value).then(response => {
    paymentList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

function hasList() {
  queryParams.value.contractId = props.contractId;
  loading.value = true;
  listPayment(queryParams.value).then(response => {
    paymentList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}


// 取消按钮
function cancel() {
  open.value = false;
  openPayment.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
    id: null,
    paymentId: null,
    contractId: null,
    startDate: null,
    endDate: null,
    rentFee: null,
    propertyFee: null,
    totalFee: null,
    actualPayment: null,
    proof: null,
    notes: null
  };
  proxy.resetForm("paymentRef");
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value
  getPayment(_id).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "修改公司支付信息";
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal.confirm('是否确认删除？').then(function() {
    return delPayment(_ids);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("删除成功");
  }).catch(() => {});
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["paymentRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        if (form.value.actualPayment == null || form.value.actualPayment === '') {
          form.value.actualPayment = 0;
        }
        checkPayment(form.value).then(response => {
          proxy.$modal.msgSuccess("修改成功");
          cancel();
          getList();
        });
      } else {
        addPayment(form.value).then(response => {
          proxy.$modal.msgSuccess("新增成功");
          cancel();
          getList();
        });
      }
    }
  });
}

function submitPayment() {
  proxy.$refs["paymentRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        if (form.value.actualPayment == null || form.value.actualPayment === '') {
          form.value.actualPayment = 0;
        }
        checkPayment(form.value).then(response => {
          proxy.$modal.msgSuccess("缴费录入成功");
          cancel();
          getList();
        });
      }
    }
  });
}

function formatTwoDecimalPlaces(row, column, cellValue) {
  // 判断值是否有效，避免显示 NaN
  if (cellValue == null || isNaN(cellValue)) {
    return '0.00';
  }
  // 使用 toFixed 保留两位小数
  return parseFloat(cellValue).toFixed(2);
}

function formatNotes(row) {
  return row.notes && row.notes.length > 0 ? row.notes : "无";
}

function getPaymentStatus(actualPayment, totalFee) {
  const statusMap = [
    { condition: (a, t) => a < t, color: 'red', text: '否' },
    { condition: (a, t) => a === t, color: 'green', text: '是' },
    { condition: (a, t) => a > t, color: 'orange', text: '数据错误' }
  ];

  const status = statusMap.find(({ condition }) => condition(actualPayment, totalFee));
  return status ? { color: status.color, text: status.text } : { color: 'black', text: '未知' };
}

function handleCheck(row) {
  reset();
  const _id = row.id || ids.value
  getPayment(_id).then(response => {
    form.value = response.data;
    openPayment.value = true;
    title.value = "缴费录入";
  });
}

getList();
</script>
