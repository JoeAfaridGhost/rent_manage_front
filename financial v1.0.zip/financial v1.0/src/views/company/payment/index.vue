<template>
  <div class="app-container">
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['company:payment:export']"
        >导出催款列表</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList" :search="false"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="paymentList" @selection-change="handleSelectionChange">
<!--      <el-table-column type="selection" width="55" align="center" />-->
<!--      <el-table-column label="序号" align="center" prop="id" />-->
      <el-table-column label="序号" align="center">
        <template #default="{ $index }">
          {{ (queryParams.pageNum - 1) * queryParams.pageSize + $index + 1 }}
        </template>
      </el-table-column>
      <el-table-column label="合同编号" align="center" prop="contractCode" />
<!--      <el-table-column label="付款编号" align="center" prop="paymentId" />-->
      <el-table-column label="公司名称" align="center" prop="companyName" />
<!--      <el-table-column label="交费时段" align="center">-->
<!--        <template #default="scope"  width="200">-->
<!--          <span>-->
<!--            {{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}-->
<!--            至-->
<!--            {{ parseTime(scope.row.endDate, '{y}-{m}-{d}') }}-->
<!--          </span>-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="开始日期" align="center" prop="startDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="结束日期" align="center" prop="endDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.endDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="租金" align="center" prop="rentFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="物业费" align="center" prop="propertyFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="交费金额（总）" align="center" prop="totalFee" :formatter="formatTwoDecimalPlaces"/>
      <el-table-column label="实际支付" align="center" prop="actualPayment"
                       :formatter="formatTwoDecimalPlaces"
      />
      <el-table-column label="付款凭证" align="center" prop="proof">
        <template #default="{ row }">
        <span v-if="row.proof">
          <a @click="handleFileView(row.proof)" style="color: blue; cursor: pointer;">
            {{ extractFileName(row.proof) }}
<!--            {{ row.proof }}-->
          </a>
        </span>
          <span v-else>无文件</span>
        </template>
      </el-table-column>
<!--      <el-table-column label="是否缴清" align="center">-->
<!--        <template #default="scope">-->
<!--        <span :style="{ color: scope.row.actualPayment >= scope.row.totalFee ? 'green' : 'red' }">-->
<!--          {{ scope.row.actualPayment >= scope.row.totalFee ? '是' : '否' }}-->
<!--        </span>-->
<!--        </template>-->
<!--      </el-table-column>-->
      <el-table-column label="是否缴清" align="center">
        <template #default="scope">
          <span :style="{ color: getPaymentStatus(scope.row.actualPayment, scope.row.totalFee).color }">
            {{ getPaymentStatus(scope.row.actualPayment, scope.row.totalFee).text }}
          </span>
        </template>
      </el-table-column>
<!--      <el-table-column label="备注" align="center" prop="notes" :formatter="formatNotes" />-->
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
<!--          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['company:payment:edit']">修改</el-button>-->
<!--          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['company:payment:remove']">删除</el-button>-->
          <el-button v-if="scope.row.actualPayment !== scope.row.totalFee "
                     link type="primary" icon="Coin" @click="handleCheck(scope.row)" v-hasPermi="['company:payment:check']">缴费录入</el-button>
          <el-button
              link type="primary" icon="Document" @click="handleGenCKD(scope.row)" v-hasPermi="['company:payment:check']">催款单</el-button>

        </template>
      </el-table-column>
    </el-table>
    
    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改公司支付信息对话框 -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="paymentRef" :model="form" :rules="rules" label-width="120px">
        <el-form-item label="实际支付" prop="actualPayment">
          <el-input v-model="form.actualPayment" placeholder="请输入实际已支付费用" />
        </el-form-item>
        <el-form-item label="付款凭证" prop="contractFile">
          <file-upload v-model="form.proof"/>
        </el-form-item>
        <el-form-item label="备注" prop="notes">
          <el-input v-model="form.notes" type="textarea" placeholder="请输入内容" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Payment">
import {
  listPayment,
  getPayment,
  delPayment,
  addPayment,
  updatePayment,
  listUnpaid,
  checkPayment
} from "@/api/company/payment";
const { proxy } = getCurrentInstance();

const paymentList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    paymentId: null,
    contractId: null,
    startDate: null,
    endDate: null,
    rentFee: null,
    propertyFee: null,
    totalFee: null,
    actualPayment: null,
    proof: null,
    notes: null
  },
  rules: {
    // paymentId: [
    //   { required: true, message: "支付唯一标识不能为空", trigger: "blur" }
    // ],
    contractId: [
      { required: true, message: "合同编号不能为空", trigger: "blur" }
    ],
    startDate: [
      { required: true, message: "开始日期不能为空", trigger: "blur" }
    ],
    endDate: [
      { required: true, message: "结束日期不能为空", trigger: "blur" }
    ],
  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询公司支付信息列表 */
function getList() {
  loading.value = true;
  listUnpaid(queryParams.value).then(response => {
    paymentList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
    id: null,
    paymentId: null,
    contractId: null,
    startDate: null,
    endDate: null,
    rentFee: null,
    propertyFee: null,
    totalFee: null,
    actualPayment: null,
    proof: null,
    notes: null
  };
  proxy.resetForm("paymentRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加公司支付信息";
}

/** 修改按钮操作 */
function handleCheck(row) {
  reset();
  const _id = row.id || ids.value
  getPayment(_id).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "缴费录入";
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["paymentRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        checkPayment(form.value).then(response => {
          proxy.$modal.msgSuccess("缴费录入成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal.confirm('是否确认删除？').then(function() {
    return delPayment(_ids);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("删除成功");
  }).catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  const currentDate = new Date().toISOString().split('T')[0];
  proxy.download('company/payment/export-unpaid', {
    ...queryParams.value
  }, `payment_${currentDate}.xlsx`)
}

function handleFileView(filePath) {
  const fullUrl =  import.meta.env.VITE_APP_BASE_API + filePath; // 拼接完整的文件 URL
  window.open(fullUrl, '_blank'); // 在新标签页中打开文件
}

// 提取文件名（从 URL 中截取文件名部分）
function extractFileName(fileUrl) {
  if (!fileUrl) return '未知文件';
  return fileUrl.split('/').pop(); // 获取 URL 中最后的部分作为文件名
}

function formatNotes(row) {
  return row.notes && row.notes.length > 0 ? row.notes : "无";
}

function formatTwoDecimalPlaces(row, column, cellValue) {
  // 判断值是否有效，避免显示 NaN
  if (cellValue == null || isNaN(cellValue)) {
    return '0.00';
  }
  // 使用 toFixed 保留两位小数
  return parseFloat(cellValue).toFixed(2);
}
function getPaymentStatus(actualPayment, totalFee) {
  const statusMap = [
    { condition: (a, t) => a < t, color: 'red', text: '否' },
    { condition: (a, t) => a === t, color: 'green', text: '是' },
    { condition: (a, t) => a > t, color: 'orange', text: '数据错误' }
  ];

  const status = statusMap.find(({ condition }) => condition(actualPayment, totalFee));
  return status ? { color: status.color, text: status.text } : { color: 'black', text: '未知' };
}

function handleGenCKD(row) {
  const _id = row.id || ids.value
  getPayment(_id).then(response => {
    const startDate = response.data.startDate;
    const endDate = response.data.endDate;
    const averageTimestamp = (new Date(startDate).getTime() + new Date(endDate).getTime()) / 2;
    const averageDate = new Date(averageTimestamp).toISOString().split('T')[0]; // 格式化为 "YYYY-MM-DD"
    const currentDate = new Date().toISOString().split('T')[0];

    console.log(row)
    const params = {
      contractId: row.contractCode,
      paymentId: response.data.paymentId,

      companyName: row.companyName,
      buildRoom: row.address,
      timePeriod: `${startDate} ~ ${endDate}`,
      rent: response.data.rentFee,
      PMFee: response.data.propertyFee,
      totalFee: response.data.totalFee,
      payTime: averageDate,
      currentDate: new Date().toISOString().split('T')[0]
    }

    console.log(params)
    proxy.download('company/payment/export-ckd', {
      ...params
    }, `催款单_${row.contractCode}_${row.companyName}_${currentDate}.docx`)
  });

}

getList();
</script>
