<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="合同编号" prop="contractId">
        <el-input
          v-model="queryParams.contractId"
          placeholder="请输入合同编号"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="公司名称" prop="company">
        <el-input
          v-model="queryParams.company"
          placeholder="请输入公司名称"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="租赁场地" prop="address">
        <el-input
          v-model="queryParams.address"
          placeholder="请输入租赁场地"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
<!--      <el-form-item label="租金单价" prop="rentPrice">-->
<!--        <el-input-->
<!--          v-model="queryParams.rentPrice"-->
<!--          placeholder="请输入租金单价"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="物业费单价" prop="propertyPrice">-->
<!--        <el-input-->
<!--          v-model="queryParams.propertyPrice"-->
<!--          placeholder="请输入物业费单价"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--            <el-form-item label="面积" prop="area">-->
<!--              <el-input-->
<!--                v-model="queryParams.area"-->
<!--                placeholder="请输入面积"-->
<!--                clearable-->
<!--                @keyup.enter="handleQuery"-->
<!--              />-->
<!--            </el-form-item>-->
      <el-form-item label="开始日期" prop="startDate">
        <el-date-picker clearable
          v-model="queryParams.startDate"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择开始日期">
        </el-date-picker>
      </el-form-item>
      <el-form-item label="结束日期" prop="endDate">
        <el-date-picker clearable
          v-model="queryParams.endDate"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择结束日期">
        </el-date-picker>
      </el-form-item>
<!--      <el-form-item label="联系人" prop="contactName">-->
<!--        <el-input-->
<!--          v-model="queryParams.contactName"-->
<!--          placeholder="请输入联系人"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="邮箱" prop="email">-->
<!--        <el-input-->
<!--          v-model="queryParams.email"-->
<!--          placeholder="请输入邮箱"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="电话" prop="phone">-->
<!--        <el-input-->
<!--          v-model="queryParams.phone"-->
<!--          placeholder="请输入电话"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="押金" prop="deposit">-->
<!--        <el-input-->
<!--          v-model="queryParams.deposit"-->
<!--          placeholder="请输入押金"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
<!--      <el-form-item label="是否审批通过" prop="approved">-->
<!--        <el-input-->
<!--          v-model="queryParams.approved"-->
<!--          placeholder="请输入是否审批通过"-->
<!--          clearable-->
<!--          @keyup.enter="handleQuery"-->
<!--        />-->
<!--      </el-form-item>-->
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
            type="warning"
            plain
            icon="Download"
            @click="handleExport"
            v-hasPermi="['company:contract:export']"
        >导出合同列表</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['company:contract:add']"
        >新增</el-button>
      </el-col>
<!--      <el-col :span="1.5">-->
<!--        <el-button-->
<!--          type="success"-->
<!--          plain-->
<!--          icon="Edit"-->
<!--          :disabled="single"-->
<!--          @click="handleUpdate"-->
<!--          v-hasPermi="['company:contract:edit']"-->
<!--        >修改</el-button>-->
<!--      </el-col>-->
<!--      <el-col :span="1.5">-->
<!--        <el-button-->
<!--          type="danger"-->
<!--          plain-->
<!--          icon="Delete"-->
<!--          :disabled="multiple"-->
<!--          @click="handleDelete"-->
<!--          v-hasPermi="['company:contract:remove']"-->
<!--        >删除</el-button>-->
<!--      </el-col>-->
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="contractList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />

      <el-table-column type="expand" v-loading="loading">
        <template #default="scope" >
          <el-tabs model-value="subModel" tab-position="left"  >
            <el-tab-pane label="缴费记录" name="subModel">
              <PaymentModule ref="subModelRef" :contractId="scope.row.contractId" :company="scope.row"/>
            </el-tab-pane>
          </el-tabs>
        </template>
      </el-table-column>

      <el-table-column label="序号" align="center">
        <template #default="{ $index }">
          {{ (queryParams.pageNum - 1) * queryParams.pageSize + $index + 1 }}
        </template>
      </el-table-column>
<!--      <el-table-column label="序号" align="center" prop="id" />-->
<!--      <el-table-column label="合同编号" align="center" prop="contractId" />-->
      <el-table-column label="合同编号" align="center" prop="contractFile">
        <template #default="{ row }">
        <span v-if="row.contractFile">
          <a @click="handleFileView(row.contractFile)" style="color: blue; cursor: pointer;">
<!--            {{ extractFileName(row.contractFile) }}-->
            {{ row.contractId }}
          </a>
        </span>
          <span v-else>{{ row.contractId }}</span>
        </template>
      </el-table-column>

      <el-table-column label="公司名称" align="center" prop="company" />
      <el-table-column label="租赁场地" align="center" prop="address"/>
<!--      <el-table-column label="租金单价" align="center" prop="rentPrice" />-->
<!--      <el-table-column label="物业单价" align="center" prop="propertyPrice" />-->
      <el-table-column label="面积(m²)" align="center" prop="area" />
      <el-table-column label="开始日期" align="center" prop="startDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.startDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
      <el-table-column label="结束日期" align="center" prop="endDate" width="180">
        <template #default="scope">
          <span>{{ parseTime(scope.row.endDate, '{y}-{m}-{d}') }}</span>
        </template>
      </el-table-column>
<!--      <el-table-column label="联系人" align="center" prop="contactName" />-->
<!--      <el-table-column label="邮箱" align="center" prop="email" />-->
<!--      <el-table-column label="电话" align="center" prop="phone" />-->
<!--      <el-table-column label="合同首付" align="center" prop="initialPayment" />-->
      <el-table-column label="押金" align="center" prop="deposit" :formatter="formatTwoDecimalPlaces"/>
<!--      <el-table-column label="合同文件" align="center" prop="contractFile" />-->
      <el-table-column label="是否审批" align="center" prop="approved">
        <template #default="{ row }">
          <span>{{ sys_yes_no.find(item => item.value === row.approved)?.label }}</span>
        </template>
      </el-table-column>
<!--      <el-table-column label="备注" align="center" prop="notes" :formatter="formatNotes" />-->
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="View" @click="handleView(scope.row)" v-hasPermi="['company:contract:list']">查看</el-button>
<!--          <template #default="{ row }">-->
<!--            -->
<!--          </template>-->
          <el-button v-if="scope.row.approved === 1" link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['company:contract:check']" >修改</el-button>
          <el-button v-if="scope.row.approved === 0" link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['company:contract:edit']" >修改</el-button>
          <el-button v-if="scope.row.approved === 0" link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['company:contract:remove']">删除</el-button>
          <el-button v-if="scope.row.approved === 0" link type="primary" icon="Check" @click="handleCheck(scope.row)" v-hasPermi="['company:contract:check']">审批通过</el-button>
          <el-button v-if="scope.row.approved === 1" link type="primary" icon="Close" @click="handleCheck(scope.row)" v-hasPermi="['company:contract:check']">取消审批</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改公司合同对话框 -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="contractRef" :model="form" :rules="rules" label-width="100px">
        <el-form-item label="合同编号" prop="contractId">
<!--          <el-input v-model="form.contractId" placeholder="请输入合同编号" :disabled="form.approved === 1" />-->
          <el-input v-model="form.contractId" placeholder="请输入合同编号" />
        </el-form-item>
        <el-form-item label="公司名称" prop="company">
<!--          <el-input v-model="form.company" placeholder="请输入公司名称" :disabled="form.approved === 1" />-->
          <el-input v-model="form.company" placeholder="请输入公司名称" />
        </el-form-item>
        <el-form-item label="租赁场地" prop="address">
<!--          <el-input v-model="form.address" placeholder="请输入租赁场地" :disabled="form.approved === 1" />-->
          <el-input v-model="form.address" placeholder="请输入租赁场地"/>
        </el-form-item>
        <el-form-item label="租金单价" prop="rentPrice">
<!--          <el-input v-model="form.rentPrice" placeholder="请输入租金单价" :disabled="form.approved === 1" />-->
          <el-input v-model="form.rentPrice" placeholder="请输入租金单价"/>
        </el-form-item>
        <el-form-item label="物业费单价" prop="propertyPrice">
<!--          <el-input v-model="form.propertyPrice" placeholder="请输入物业费单价" :disabled="form.approved === 1" />-->
          <el-input v-model="form.propertyPrice" placeholder="请输入物业费单价"/>
        </el-form-item>
        <el-form-item label="面积" prop="area">
          <el-input v-model="form.area" placeholder="请输入内容"/>
<!--          <el-input v-model="form.area" placeholder="请输入内容" :disabled="form.approved === 1" />-->
        </el-form-item>
        <el-form-item label="开始日期" prop="startDate">
<!--          <el-date-picker clearable v-model="form.startDate" type="date" value-format="YYYY-MM-DD" placeholder="请选择开始日期"-->
<!--                          :disabled="form.approved === 1" >-->
<!--          </el-date-picker>          -->
          <el-date-picker clearable v-model="form.startDate" type="date" value-format="YYYY-MM-DD" placeholder="请选择开始日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="结束日期" prop="endDate">
          <el-date-picker clearable
            v-model="form.endDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择结束日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="联系人" prop="contactName">
          <el-input v-model="form.contactName" placeholder="请输入联系人" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" placeholder="请输入邮箱" />
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="form.phone" placeholder="请输入电话" />
        </el-form-item>
        <el-form-item label="押金" prop="deposit">
          <el-input v-model="form.deposit" placeholder="请输入押金" />
        </el-form-item>
        <el-form-item label="合同文件" prop="contractFile">
          <file-upload v-model="form.contractFile"/>
        </el-form-item>
        <el-form-item label="是否审批通过" prop="approved">
          <el-radio-group v-model="form.approved" :disabled="true">
            <el-radio
                v-for="dict in sys_yes_no"
                :key="dict.value"
                :label="dict.value"
            >{{dict.label}}</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="notes">
          <el-input v-model="form.notes" type="textarea" placeholder="请输入内容" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>


    <el-dialog title="公司详细信息" v-model="openView" width="700px" append-to-body>
      <el-form :model="form" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="公司名称：">{{ displayValue(form.company) }}</el-form-item>
            <el-form-item label="合同编号：">{{ displayValue(form.contractId) }}</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="租赁场地：">{{ displayValue(form.address) }}</el-form-item>
            <el-form-item label="面积(m²)：">{{ displayValue(form.area) }}</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="租金单价：">{{ displayValue(form.rentPrice) }}</el-form-item>
            <el-form-item label="物业费单价：">{{ displayValue(form.propertyPrice) }}</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="开始日期：">{{ displayValue(form.startDate) }}</el-form-item>
            <el-form-item label="结束日期：">{{ displayValue(form.endDate) }}</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="联系人：">{{ displayValue(form.contactName) }}</el-form-item>
            <el-form-item label="邮箱：">{{ displayValue(form.email) }}</el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="电话：">{{ displayValue(form.phone) }}</el-form-item>
            <el-form-item label="押金：">{{ displayValue(form.deposit) }}</el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <el-form-item label="备注：">{{ displayValue(form.notes) }}</el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="openView = false">关  闭</el-button>
        </div>
      </template>
    </el-dialog>

  </div>
</template>

<script setup name="Contract">
import {
  listContract,
  getContract,
  delContract,
  addContract,
  updateContract,
  checkContract
} from "@/api/company/contract";
import PaymentModule from "@/views/company/contract/paymentModule.vue";

const { proxy } = getCurrentInstance();
const sys_yes_no = ref([
  {label: '是', value: 1},
  {label: '否', value: 0}
])

const contractList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");
const openView = ref(false);
const openAddress = ref(false);
const selectedAddresses = ref([])  // 存储已选场地

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    contractId: null,
    company: null,
    address: null,
    rentPrice: null,
    propertyPrice: null,
    area: null,
    startDate: null,
    endDate: null,
    contactName: null,
    email: null,
    phone: null,
    deposit: null,
    contractFile: null,
    approved: null,
    notes: null,
    // orderByColumn: "startDate",
    // isAsc: "desc"
  },
  rules: {
    address: [
      { required: true, message: "租赁场地不能为空", trigger: "blur" }
    ],
    rentPrice: [
      { required: true, message: "租金单价不能为空", trigger: "blur" }
    ],
    propertyPrice: [
      { required: true, message: "物业单价不能为空", trigger: "blur" }
    ],
    contractId: [
      { required: true, message: "合同编号不能为空", trigger: "blur" }
    ],
    company: [
      { required: true, message: "公司名称不能为空", trigger: "blur" }
    ],
    startDate: [
      { required: true, message: "开始日期不能为空", trigger: "blur" }
    ],
    endDate: [
      { required: true, message: "结束日期不能为空", trigger: "blur" }
    ],
    area: [
      { required: true, message: "面积不能为空", trigger: "blur" }
    ],
  }
});

const { queryParams, form, rules } = toRefs(data);


// 点击文件名时处理查看逻辑
function handleFileView(filePath) {
  const fullUrl =  import.meta.env.VITE_APP_BASE_API + filePath; // 拼接完整的文件 URL
  window.open(fullUrl, '_blank'); // 在新标签页中打开文件
}

// 提取文件名（从 URL 中截取文件名部分）
function extractFileName(fileUrl) {
  if (!fileUrl) return '未知文件';
  return fileUrl.split('/').pop(); // 获取 URL 中最后的部分作为文件名
}

/** 查询公司合同列表 */
function getList() {
  loading.value = true;
  listContract(queryParams.value).then(response => {
    contractList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}

// 表单重置
function reset() {
  form.value = {
    siteIds: null,
    id: null,
    contractId: null,
    company: null,
    address: null,
    rentPrice: null,
    propertyPrice: null,
    area: null,
    startDate: null,
    endDate: null,
    contactName: null,
    email: null,
    phone: null,
    deposit: null,
    contractFile: null,
    approved: null,
    notes: null
  };
  proxy.resetForm("contractRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.contractId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加公司合同";
  form.value.approved = 0;
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value
  getContract(_id).then(response => {
    form.value = response.data;
    open.value = true;
    title.value = "修改公司合同";
  });
}

/** 审批按钮操作 */
function handleCheck(row) {
  reset();
  const _id = row.id || ids.value
  getContract(_id).then(response => {
    if(response.data.approved === 0){
      response.data.approved = 1
      title.value = "审批公司合同";
      checkContract(response.data).then(resp => {
        proxy.$modal.msgSuccess("审批成功");
        getList();
      });
    }else{
      proxy.$modal.confirm('是否取消审批？').then(function() {
        response.data.approved = 0
        title.value = "审批公司合同";
        return checkContract(response.data);
      }).then(() => {
        getList();
        proxy.$modal.msgSuccess("取消审批");
      }).catch(() => {});
    }
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["contractRef"].validate(valid => {
    if (valid) {
      if (form.value.id != null) {
        updateContract(form.value).then(response => {
          proxy.$modal.msgSuccess("修改成功");
          open.value = false;
          getList();
        });
      } else {
        addContract(form.value).then(response => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.contractId || ids.value;
  proxy.$modal.confirm('是否确认删除合同编号为' + _ids + '的合同？').then(function() {
    return delContract(_ids);
  }).then(() => {
    getList();
    proxy.$modal.msgSuccess("删除成功");
  }).catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  const currentDate = new Date().toISOString().split('T')[0];
  proxy.download('company/contract/export', {
    ...queryParams.value
  }, `contract_${currentDate}.xlsx`)
}

function handleView(row) {
  getContract(row.id).then(response => {
    form.value = response.data;
    openView.value = true;
  })
}

function formatTwoDecimalPlaces(row, column, cellValue) {
  // 判断值是否有效，避免显示 NaN
  if (cellValue == null || isNaN(cellValue)) {
    return '0.00';
  }
  // 使用 toFixed 保留两位小数
  return parseFloat(cellValue).toFixed(2);
}

function displayValue(value) {
  return value != null && value.toString().trim().length > 0 ? value : '空';
}
getList();
</script>
